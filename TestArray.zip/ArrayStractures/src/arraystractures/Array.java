
package arraystractures;

import java.util.Arrays;

public class Array {
    public static void main(String[] args) {
        
        int[] amount= new int[10];
        
        amount[0]=963;
        amount[1]=485;
        amount[2]=100;
        amount[3]=657;
        amount[4]=100;
        amount[6]=987;
        amount[7]=300;
        amount[8]=400;
        amount[9]=250;
        
        System.out.println(Arrays.toString(amount));
        
        
        for(int tk: amount){
            System.out.println(tk);}
    }
    
}
