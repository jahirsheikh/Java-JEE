
package arraystractures;

import java.util.Arrays;
import java.util.Scanner;

public class IntArray {
    public static void main(String[] args) {
        int sum=0;
        Scanner in= new Scanner(System.in);
        System.out.println("Enter array size :");
        int size =in.nextInt();
        int[] number= new int[size];
        
//        number[0]=1;
//        number[1]=11;
//        number[2]=22;
//        number[3]=33;
//        number[4]=44;
//        number[5]=55;
//        number[6]=66;
//        number[7]=77;
//        number[8]=88;
//        number[9]=99;
        
        for(int i=0; i<number.length; i++){
                number[i]=(int)(Math.random()*100);
        }
//        System.out.println(Arrays.toString(number));
        
        int max=number[0];
        int min=number[0];
        int maxNumber=0;
        int minNumber=999999;
        for(int n:number){
          if(n>maxNumber){
          maxNumber=n;}
          else if(n<minNumber){
          minNumber=n;}
          
//        max =n>max ? n:max;
//        min =n<min ? n:min;
        
        }
       
        System.out.println(Arrays.toString(number));
        System.out.println("Max no is = "+maxNumber+ " Min no is = "+ minNumber);
        
        
       
    }
}
