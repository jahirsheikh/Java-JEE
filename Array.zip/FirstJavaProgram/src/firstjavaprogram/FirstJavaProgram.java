
package firstjavaprogram;

import java.util.Scanner;


public class FirstJavaProgram {
    


    public static void main(String[] args) {
          
        Scanner in= new Scanner(System.in);
        
//        char ch= in.next().charAt(0);
//        
//        
//        if(ch>=(char)65 && ch<=(char)90){
//            System.out.println("Uppaer Case");
//            System.out.println((int)ch);
//            System.out.println(Integer.toBinaryString((int)ch));
//        
//        }
//        else {
//            System.out.println("Lower Case");
//            System.out.println((int)ch);
//            System.out.println(Integer.toBinaryString((int)ch));
//        }
//        
//        String name= "Java";
        
//        System.out.println(name.length());
//        System.out.println(name.charAt(2));
//        System.out.println(name.charAt(2));
//        
        
       
//
//String message = "Welcome to Java";
// message = message.substring(2,13)+"Jahir";
//        System.out.println(message);

for(int i =1; i<=10; i=i+1){
    
    System.out.println("Hello " +i);

}
          
    }
    
}

