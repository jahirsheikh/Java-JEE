
package arraystractures;

import java.util.Arrays;


public class ArrayStractures {

    
    public static void main(String[] args) {
        String[] studenName= new String[10];
        
        studenName[0]="Masud";
        studenName[1]="Hasan";
        
        System.out.println(Arrays.toString(studenName));
        
        int[] mark = new int[10];
        
        mark[0]=30;
        mark[1]=60;
        mark[2]=90;
        System.out.println(Arrays.toString(mark));
        
        for(int i=0; i<studenName.length; i++){
            System.out.println(studenName[i]);
        }
        
        for(String name:studenName){
            System.out.println(name);}
        
    }

  
    }
    

